<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PatientCurrentStatus extends Model
{
    protected $table = "patient_current_status";
}
