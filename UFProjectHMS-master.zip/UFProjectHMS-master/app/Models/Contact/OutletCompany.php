<?php

namespace App\Models\Contact;

use Illuminate\Database\Eloquent\Model;

class OutletCompany extends Model
{
    protected $table = 'outlet_companys';
}
