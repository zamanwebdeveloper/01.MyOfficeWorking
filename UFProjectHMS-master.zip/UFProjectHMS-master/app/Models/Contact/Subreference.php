<?php

namespace App\Models\Contact;

use Illuminate\Database\Eloquent\Model;

class Subreference extends Model
{
    protected $table = 'customer_sub_reference';


    public $timestamps = false;


}