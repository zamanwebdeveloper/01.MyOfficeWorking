<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DoctorVisitHistory extends Model
{
    protected $table = "doctor_visit_histories";
}
