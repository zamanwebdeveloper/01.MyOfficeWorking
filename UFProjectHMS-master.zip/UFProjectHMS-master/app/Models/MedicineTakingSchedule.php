<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MedicineTakingSchedule extends Model
{
    protected $table = "medicine_taking_schedules";
}
