<?php

namespace App\Models\Deshboard;

use Illuminate\Database\Eloquent\Model;

class Reminder extends Model
{
    protected $table = "reminders";
}
