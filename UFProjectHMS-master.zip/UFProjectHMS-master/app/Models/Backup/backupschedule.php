<?php

namespace App\Models\Backup;

use Illuminate\Database\Eloquent\Model;

class backupschedule extends Model
{
    protected $table = "backupschedules";
}
