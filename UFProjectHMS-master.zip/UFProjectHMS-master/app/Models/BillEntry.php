<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BillEntry extends Model
{
    protected $table = "bill_entry";
}
