<?php

namespace App\Models\Template;

use Illuminate\Database\Eloquent\Model;

class HeaderTemplate extends Model
{
    protected $table = "headertemplate";
}
