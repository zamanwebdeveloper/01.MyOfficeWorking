<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StuffType extends Model
{
    protected $table = "stuff_type";
}
