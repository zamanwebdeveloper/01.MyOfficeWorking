# hospital-management-system
Created with Php, Mysqli, Bootstrap. This project will meet the professional standards required inorder to be functional within an organisation. This project can also be used by Btech Students.
