   <link href="assets/css/bootstrap.css" rel="stylesheet"/>
    <link href="assets/css/bootstrap-responsive.css" rel="stylesheet"/>
	<link href="assets/css/docs.css" rel="stylesheet"/>
	 
    <link href="assets/style.css" rel="stylesheet"/>
	<link href="assets/js/google-code-prettify/prettify.css" rel="stylesheet"/>
    
<br /><br /><br /><center>
<h1>17 Edsa cor Pantaleon U.G34 City land Pioneer Mandaluyong City</h1>
<hr />
<img src="img/Map.jpg" /><br />

<hr />
<form action="index.php" method="get">
<div class="control-group">
			<div class="controls">
				
				<input class="btn btn-large btn-primary  " name="submit" type="submit" value="Back" />
			</div>
		</div></form>
</center>