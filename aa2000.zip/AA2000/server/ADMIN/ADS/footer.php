     <center> <footer>
        <p>&copy; AA2000 Security and Technology <?php echo date("Y")?></p>
      </footer> </center>