<?php
	include('include/connect.php');
    
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
     <link rel="shortcut icon" href="img/aalogo.jpg">

    <title>AA2000 Security and Technology</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
<link href="assets/css/bootstrap.css" rel="stylesheet"/>
<div class="well">

<center>
<form action="mail.php" method="post">
INPUT YOUR EMAIL ADDRESS: <input type="text" name="email" placeholder="Email Address" class="form-control" required />
<br />
<input type="submit" name="submit" value="Send"  class="btn btn-success"/>
</form>
</center>

</div>

