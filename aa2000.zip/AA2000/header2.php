<header id="header">
<div class="row">
<div class="span12">
	<a href="index.php"><img src="img/AA2000.jpg" alt=""/></a><embed src="img/cart.gif" class="pull-right"></embed></div> </div>



<div class="clr"></div>
</header>