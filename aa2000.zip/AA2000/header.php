<header id="header">
<div class="row">
<div class="span12">
	<a href="index.php"><img class="pull-left" src="img/AA2000.jpg" alt=""/> <img  class="pull-right" src="img/a.jpg" /></a>
</div>
</div>
<div class="clr"></div>


</header>