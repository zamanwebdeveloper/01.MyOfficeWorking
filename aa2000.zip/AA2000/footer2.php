<div class="row">
		<div class="span3">
			<h5><font color="black">Company Address</font></h5>
<b><font color="black"> &nbsp; &nbsp;Main Office</b>:
The company is located at  &nbsp; &nbsp; 17 Edsa cor Pantaleon U.G34 City land  &nbsp; &nbsp; &nbsp;Pioneer Mandaluyong City

		 </div>

		 <div class="span3">
			<h5>Email Address:</h5>   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   sales@aa2000ph.com<br/>
			<p>   Website:http://aa2000ph.blogspot.com/  &nbsp;Contact No:(632)/747-6805/747-3642/571-5693/(02)571-5693</p>
		 </div></font>
		
		<div id="socialMedia" class="span3 pull-right"></font>    
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	<font color="black"><b>SOCIAL MEDIA </b></font><br />
            
			<a href="https://www.facebook.com/AA2000Enterprises"><img width="60" src="assets/img/facebook.png" title="facebook"/></a>
			<a href="#"><img width="60" src="assets/img/twitter.png" title="twitter"/></a>
			<a href="#"><img width="60" src="assets/img/rss.png" title="rss"/></a>
			<a href="#"><img width="60" src="assets/img/youtube.png" title="youtube"/></a>
		 </div> 
	 </div><center>
   
	 <hr class="soft">
	<p class=""><marquee><font color="black">&copy; AA 2000 Security and Technology Solution Inc. <?php echo date("Y")?></font></marquee></p>
	</div><!-- /container --></center>


    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
    <script src="assets/js/jquery.js"></script>
	<script src="assets/js/google-code-prettify/prettify.js"></script>
    <script src="assets/js/application.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>
    <script src="assets/js/bootstrap-affix.js"></script>
    <script src="assets/js/jquery.lightbox-0.5.js"></script>
	<script src="assets/js/bootsshoptgl.js"></script>
	 <script type="text/javascript">
    $(function() {
        $('#gallery a').lightBox();
    });
    </script>
  </body>
</html>