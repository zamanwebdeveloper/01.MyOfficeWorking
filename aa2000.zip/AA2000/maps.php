     <head>
    <meta charset="utf-8">
     <link rel="shortcut icon" href="img/aalogo.jpg">

    <title>AA2000 Security and Technology</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    </head>
   
   <link href="assets/css/bootstrap.css" rel="stylesheet"/>
    <link href="assets/css/bootstrap-responsive.css" rel="stylesheet"/>
	<link href="assets/css/docs.css" rel="stylesheet"/>
	 
    <link href="assets/style.css" rel="stylesheet"/>
	<link href="assets/js/google-code-prettify/prettify.css" rel="stylesheet"/>
    
<br /><br /><br /><center>
<h1>17 Edsa cor Pantaleon U.G34 City land Pioneer Mandaluyong City</h1>
<hr />
<img src="img/Map.jpg" /><br />

<hr />
<form action="user_index.php" method="get">
<div class="control-group">
			<div class="controls">
				
				<input class="btn btn-large btn-primary  " name="submit" type="submit" value="Back" />
			</div>
		</div></form>
</center>